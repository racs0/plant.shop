package at.htl.planetshop;

/**
 * Created by oscaryim on 20.11.17.
 */


import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

import at.htl.planetshop.Helper.SpacesItemDecoration;
import at.htl.planetshop.Entity.Product;

/**
 * Created by oscaryim on 13.11.17.
 */

public class ShoppingActivity extends AppCompatActivity{
    private RecyclerView shoppingRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shopping_activity);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        shoppingRecyclerView = (RecyclerView)findViewById(R.id.product_list);
        GridLayoutManager mGrid = new GridLayoutManager(ShoppingActivity.this, 2);
        shoppingRecyclerView.setLayoutManager(mGrid);
        shoppingRecyclerView.setHasFixedSize(true);
        shoppingRecyclerView.addItemDecoration(new SpacesItemDecoration(2, 12, false));
        ShopRecyclerViewAdapter shopAdapter = new ShopRecyclerViewAdapter(ShoppingActivity.this, getAllProducts());
        shoppingRecyclerView.setAdapter(shopAdapter);
    }
    private List<Product> getAllProducts(){
        List<Product> products = new ArrayList<Product>();
        products.add(new Product(1, "Döner", 420, R.drawable.product1));
        products.add(new Product(2, "Leberkas", 3.50, R.drawable.product2));
        return products;
    }
}
