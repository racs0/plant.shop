package at.htl.planetshop;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import at.htl.planetshop.Entity.Product;

/**
 * Created by oscaryim on 20.11.17.
 */

public class ProductActivity extends AppCompatActivity {
    private TextView productPrice;
    private ImageView productImage;
    private Gson gson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        productImage = (ImageView)findViewById(R.id.full_product_image);

        productPrice = (TextView)findViewById(R.id.product_price);
        GsonBuilder builder = new GsonBuilder();
        gson = builder.create();
        String productInStringFormat = getIntent().getExtras().getString("PRODUCT");
        final Product singleProduct = gson.fromJson(productInStringFormat, Product.class);
        if(singleProduct != null){
            setTitle(singleProduct.getName());
            productImage.setImageResource(singleProduct.getImage());
            productPrice.setText("Price: " + String.valueOf(new Double(singleProduct.getPrice()).intValue()) + " €");
        }
        Button addToCartButton = (Button)findViewById(R.id.add_to_cart);
        assert addToCartButton != null;
        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }
    private List<Product> convertObjectArrayToListObject(Product[] allProducts){
        List<Product> mProduct = new ArrayList<Product>();
        Collections.addAll(mProduct, allProducts);
        return mProduct;
    }

}
