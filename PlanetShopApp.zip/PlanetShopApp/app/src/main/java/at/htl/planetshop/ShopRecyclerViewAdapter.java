package at.htl.planetshop;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.List;

import at.htl.planetshop.Entity.Product;

/**
 * Created by oscaryim on 20.11.17.
 */

public class ShopRecyclerViewAdapter extends RecyclerView.Adapter<ShopRecyclerViewHolder> {
    private Context context;
    private List<Product> allProducts;

    public ShopRecyclerViewAdapter(Context context, List<Product> allProducts) {
        this.context = context;
        this.allProducts = allProducts;
    }
    @Override
    public ShopRecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_listing, parent, false);
        ShopRecyclerViewHolder productHolder = new ShopRecyclerViewHolder(layoutView);
        return productHolder;
    }
    @Override
    public void onBindViewHolder(ShopRecyclerViewHolder holder, int position) {
        final Product singleProduct = allProducts.get(position);
        holder.productName.setText(singleProduct.getName());
        holder.produceImage.setImageResource(singleProduct.getImage());
        holder.produceImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GsonBuilder builder = new GsonBuilder();
                Gson gson = builder.create();

            }
        });
    }
    @Override
    public int getItemCount() {
        return allProducts.size();
    }
}
